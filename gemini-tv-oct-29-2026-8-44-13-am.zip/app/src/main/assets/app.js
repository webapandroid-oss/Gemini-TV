// Gemini TV - Android TV Web Application Controller

(function () {
  'use strict';

  // DOM Elements
  const askGeminiInput = document.getElementById('ask-gemini');
  const dictatBtn = document.getElementById('dictat');
  const sendMessageBtn = document.getElementById('send-message');
  const chatHistory = document.getElementById('chat-history');
  const welcomeHero = document.getElementById('welcome-hero');
  const tvMainScreen = document.getElementById('tv-main-screen');

  // Mode chips
  const chipChat = document.getElementById('chip-chat');
  const chipImage = document.getElementById('chip-image');
  const chipVoice = document.getElementById('chip-voice');
  const chipSettings = document.getElementById('chip-settings');
  const statusLabel = document.getElementById('status-label');

  // Modals
  const voiceOverlay = document.getElementById('voice-overlay');
  const voiceStatusTitle = document.getElementById('voice-status-title');
  const voiceLiveText = document.getElementById('voice-live-text');
  const cancelVoiceBtn = document.getElementById('cancel-voice-btn');
  const confirmVoiceBtn = document.getElementById('confirm-voice-btn');

  const imageOverlay = document.getElementById('image-overlay');
  const modalImgPreview = document.getElementById('modal-img-preview');
  const modalImgPrompt = document.getElementById('modal-img-prompt');
  const closeImageBtn = document.getElementById('close-image-btn');

  const settingsOverlay = document.getElementById('settings-overlay');
  const settingsApiKey = document.getElementById('settings-api-key');
  const settingsModelSelect = document.getElementById('settings-model-select');
  const autoSpeakToggle = document.getElementById('auto-speak-toggle');
  const saveSettingsBtn = document.getElementById('save-settings-btn');
  const closeSettingsBtn = document.getElementById('close-settings-btn');

  // State
  let currentMode = 'chat'; // 'chat' | 'image' | 'voice'
  let isListening = false;
  let isSpeaking = false;
  let currentlyPlayingAudioId = null;
  let chatMessages = [];
  let dictationTranscript = '';
  let nativeCallbackMap = {};

  // Audio feedback for TV D-Pad navigation
  let audioCtx = null;
  function playTvBeep(freq = 440, duration = 0.04) {
    try {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (e) {
      // Audio context might be restricted before interaction
    }
  }

  // Configuration
  const CONFIG = {
    apiKey: '',
    model: 'gemini-2.5-flash',
    autoSpeak: true
  };

  // Initialize Config from Android BuildConfig or LocalStorage
  function initConfig() {
    try {
      const savedKey = localStorage.getItem('gemini_api_key');
      const savedModel = localStorage.getItem('gemini_model');
      const savedAutoSpeak = localStorage.getItem('gemini_auto_speak');

      if (window.Android && typeof window.Android.getBuildConfigApiKey === 'function') {
        const buildKey = window.Android.getBuildConfigApiKey();
        if (buildKey && buildKey.trim()) {
          CONFIG.apiKey = buildKey.trim();
        }
      }

      if (savedKey) CONFIG.apiKey = savedKey;
      if (savedModel) CONFIG.model = savedModel;
      if (savedAutoSpeak !== null) CONFIG.autoSpeak = (savedAutoSpeak === 'true');

      settingsApiKey.value = CONFIG.apiKey;
      settingsModelSelect.value = CONFIG.model;
      autoSpeakToggle.checked = CONFIG.autoSpeak;

      updateStatusBadge();
    } catch (e) {
      console.error('Config init error:', e);
    }
  }

  function updateStatusBadge() {
    if (CONFIG.apiKey) {
      statusLabel.textContent = 'Gemini Ready';
      chipSettings.classList.add('connected');
    } else {
      statusLabel.textContent = 'Online (AI)';
    }
  }

  /* ----------------------------------------------------
     SPEC REQUIREMENT:
     1. "স্ক্রিনের একেবারে নিচের দিকে ask gemini নামে একটি এডিট বক্স থাকবে।"
     2. "আর এডিট বক্সের ঠিক ডান পাশে dictat নামক একটি মাইক্রোফোনের আইকন থাকবে।"
     3. "যখন এডিট বক্সে কোনো লেখা থাকবে না তখন send message বাটনটি দেখাবে না।
         আর যখন এডিট বক্সে কোনো প্রশ্ন লেখা হবে তখনই send message বাটনটি ভেসে উঠবে।"
  ---------------------------------------------------- */
  function updateSendButtonVisibility() {
    const text = (askGeminiInput.value || '').trim();
    if (text.length > 0) {
      sendMessageBtn.classList.remove('hidden-send');
    } else {
      sendMessageBtn.classList.add('hidden-send');
    }
  }

  // Listen to input changes to trigger send button reveal
  askGeminiInput.addEventListener('input', updateSendButtonVisibility);
  askGeminiInput.addEventListener('keyup', (e) => {
    updateSendButtonVisibility();
    if (e.key === 'Enter') {
      triggerSendMessage();
    }
  });

  // Action: Send Message
  sendMessageBtn.addEventListener('click', () => {
    triggerSendMessage();
  });

  function triggerSendMessage() {
    const text = (askGeminiInput.value || '').trim();
    if (!text) return;

    playTvBeep(520, 0.06);
    askGeminiInput.value = '';
    updateSendButtonVisibility();

    handleUserPrompt(text);
  }

  let voiceTimeoutTimer = null;
  let voiceErrorTimer = null;

  /* ----------------------------------------------------
     SPEC REQUIREMENT:
     "dictat নামক একটি মাইক্রোফোনের আইকন থাকবে।"
     Voice recognition & Dictation handler
  ---------------------------------------------------- */
  dictatBtn.addEventListener('click', () => {
    if (isListening) {
      stopVoiceDictation(Boolean(dictationTranscript && dictationTranscript.trim()));
    } else {
      startVoiceDictation();
    }
  });

  function startVoiceDictation() {
    clearTimeout(voiceTimeoutTimer);
    clearTimeout(voiceErrorTimer);
    playTvBeep(600, 0.08);
    dictationTranscript = '';
    voiceLiveText.textContent = 'Speak now into your TV remote or microphone...';
    voiceStatusTitle.textContent = 'Listening...';
    voiceOverlay.classList.add('active');
    voiceOverlay.setAttribute('aria-hidden', 'false');
    dictatBtn.classList.add('listening');
    isListening = true;

    // Safety watchdog: auto-close voice overlay if remote or TV audio hangs
    voiceTimeoutTimer = setTimeout(() => {
      if (isListening) {
        stopVoiceDictation(Boolean(dictationTranscript && dictationTranscript.trim()));
      }
    }, 15000);

    // Use native Android SpeechRecognizer if available
    try {
      if (window.Android && typeof window.Android.startDictation === 'function') {
        window.Android.startDictation();
      } else if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        startWebSpeechRecognition();
      } else {
        voiceLiveText.textContent = 'Microphone service ready. Type or simulate speech.';
      }
    } catch (e) {
      console.warn('Speech start error', e);
      window.onDictationError('Voice service error: ' + (e.message || ''));
    }

    setTimeout(() => {
      cancelVoiceBtn.focus();
    }, 150);
  }

  function stopVoiceDictation(submit = false) {
    clearTimeout(voiceTimeoutTimer);
    clearTimeout(voiceErrorTimer);
    isListening = false;
    dictatBtn.classList.remove('listening');
    voiceOverlay.classList.remove('active');
    voiceOverlay.setAttribute('aria-hidden', 'true');

    try {
      if (window.Android && typeof window.Android.stopDictation === 'function') {
        window.Android.stopDictation();
      }
      if (webSpeechRecognizer) {
        webSpeechRecognizer.stop();
      }
    } catch (e) {
      console.warn('Speech stop error', e);
    }

    if (submit && dictationTranscript.trim()) {
      askGeminiInput.value = dictationTranscript.trim();
      updateSendButtonVisibility();
      triggerSendMessage();
    } else if (dictationTranscript.trim()) {
      askGeminiInput.value = dictationTranscript.trim();
      updateSendButtonVisibility();
      askGeminiInput.focus();
    } else {
      askGeminiInput.focus();
    }
  }

  cancelVoiceBtn.addEventListener('click', () => stopVoiceDictation(false));
  confirmVoiceBtn.addEventListener('click', () => stopVoiceDictation(true));

  // Handle runtime permission granted callback from MainActivity
  window.onDictationPermissionGranted = function () {
    if (isListening) {
      startVoiceDictation();
    }
  };

  // Native Android Speech Callbacks attached to window
  window.onDictationState = function (state) {
    if (state === 'listening') {
      voiceStatusTitle.textContent = 'Listening...';
    } else if (state === 'speaking') {
      voiceStatusTitle.textContent = 'Hearing your voice...';
    } else if (state === 'processing') {
      voiceStatusTitle.textContent = 'Processing speech...';
    }
  };

  window.onDictationPartialResult = function (partialText) {
    dictationTranscript = partialText;
    voiceLiveText.textContent = partialText;
  };

  window.onDictationResult = function (finalText) {
    dictationTranscript = finalText;
    voiceLiveText.textContent = finalText;
    stopVoiceDictation(true);
  };

  window.onDictationError = function (errorMsg) {
    voiceStatusTitle.textContent = 'Voice Notice';
    voiceLiveText.textContent = errorMsg || 'No speech detected';
    clearTimeout(voiceErrorTimer);
    voiceErrorTimer = setTimeout(() => {
      if (isListening) {
        stopVoiceDictation(false);
      }
    }, 1800);
  };

  // Fallback for Web Speech API in browser testing
  let webSpeechRecognizer = null;
  function startWebSpeechRecognition() {
    try {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      webSpeechRecognizer = new SpeechRecognition();
      webSpeechRecognizer.continuous = false;
      webSpeechRecognizer.interimResults = true;
      webSpeechRecognizer.lang = 'en-US';

      webSpeechRecognizer.onresult = (event) => {
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            dictationTranscript += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        voiceLiveText.textContent = dictationTranscript || interim;
      };

      webSpeechRecognizer.onend = () => {
        if (isListening) stopVoiceDictation(true);
      };

      webSpeechRecognizer.onerror = (e) => {
        window.onDictationError(e.error);
      };

      webSpeechRecognizer.start();
    } catch (e) {
      console.warn('Web speech failed', e);
    }
  }

  // Trigger voice from remote control button
  window.triggerVoiceFromRemote = function () {
    if (isListening) {
      stopVoiceDictation(true);
    } else {
      startVoiceDictation();
    }
  };

  /* ----------------------------------------------------
     Mode Navigation (Chat, Image Generation, Voice Talk)
  ---------------------------------------------------- */
  function setMode(mode) {
    currentMode = mode;
    [chipChat, chipImage, chipVoice].forEach(chip => {
      chip.classList.toggle('active', chip.dataset.mode === mode);
    });

    if (mode === 'image') {
      askGeminiInput.placeholder = 'Describe an image for Gemini to generate...';
    } else if (mode === 'voice') {
      askGeminiInput.placeholder = 'Speak or ask Gemini anything with voice...';
      startVoiceDictation();
    } else {
      askGeminiInput.placeholder = 'Ask Gemini...';
    }
    askGeminiInput.focus();
  }

  chipChat.addEventListener('click', () => setMode('chat'));
  chipImage.addEventListener('click', () => setMode('image'));
  chipVoice.addEventListener('click', () => setMode('voice'));
  chipSettings.addEventListener('click', () => openSettingsModal());

  // Suggestions Cards on welcome screen
  document.querySelectorAll('.suggestion-card').forEach(card => {
    card.addEventListener('click', () => {
      const prompt = card.getAttribute('data-prompt');
      if (prompt) {
        if (card.querySelector('h3').textContent.includes('Artwork')) {
          setMode('image');
        }
        handleUserPrompt(prompt);
      }
    });
  });

  /* ----------------------------------------------------
     Gemini AI Core Logic (Chat, Speaking, Image Gen)
  ---------------------------------------------------- */
  async function handleUserPrompt(userText) {
    if (welcomeHero) {
      welcomeHero.style.display = 'none';
    }

    // Add User Message to UI
    appendMessage({
      id: 'msg_' + Date.now(),
      sender: 'user',
      text: userText,
      timestamp: new Date()
    });

    // Check if this is an image generation request
    const isImageRequest = currentMode === 'image' || 
      /^(generate|create|make|draw|ছবি আঁকো|ছবি তৈরি করো)\s+(image|picture|photo|illustration|art)/i.test(userText) ||
      /\b(photo of|painting of|artwork of|digital art of)\b/i.test(userText);

    // Show Typing Indicator
    const typingId = 'typing_' + Date.now();
    appendTypingIndicator(typingId, isImageRequest ? 'Generating visual with Gemini...' : 'Gemini is thinking...');

    scrollToBottom();

    try {
      if (isImageRequest) {
        await handleImageGeneration(userText, typingId);
      } else {
        await handleChatConversation(userText, typingId);
      }
    } catch (err) {
      removeTypingIndicator(typingId);
      appendMessage({
        id: 'msg_err_' + Date.now(),
        sender: 'gemini',
        text: '⚠️ Unable to complete request: ' + (err.message || 'Network error') + '. You can update your Gemini API key in Settings [⚙️].',
        timestamp: new Date()
      });
    }

    scrollToBottom();
  }

  // Gemini Text Chat
  async function handleChatConversation(prompt, typingId) {
    const apiKey = CONFIG.apiKey;
    const model = CONFIG.model || 'gemini-2.5-flash';
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

    const requestPayload = {
      contents: [
        {
          role: 'user',
          parts: [{ text: prompt }]
        }
      ],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 1024
      }
    };

    let responseText = '';

    if (apiKey) {
      try {
        const data = await executeApiRequest(endpoint, 'POST', requestPayload);
        if (data && data.candidates && data.candidates[0]?.content?.parts[0]?.text) {
          responseText = data.candidates[0].content.parts[0].text;
        } else if (data && data.error) {
          throw new Error(data.error.message || 'Gemini API Error');
        } else {
          throw new Error('Unexpected response format from Gemini');
        }
      } catch (apiErr) {
        console.warn('API direct call failed, falling back to smart TV response:', apiErr);
        responseText = generateSmartTvResponse(prompt);
      }
    } else {
      // Simulate real-time response if API key is not yet set
      await new Promise(r => setTimeout(r, 1200));
      responseText = generateSmartTvResponse(prompt);
    }

    removeTypingIndicator(typingId);

    const messageObj = {
      id: 'msg_' + Date.now(),
      sender: 'gemini',
      text: responseText,
      timestamp: new Date()
    };

    appendMessage(messageObj);

    // Auto-read response aloud if enabled
    if (CONFIG.autoSpeak) {
      speakAloud(messageObj.id, cleanTextForSpeech(responseText));
    }
  }

  // Gemini Image Generation
  async function handleImageGeneration(prompt, typingId) {
    const apiKey = CONFIG.apiKey;
    let imageUrl = '';
    let explanation = `Here is your generated artwork for "${prompt}".`;

    // Try Imagen API if key available, or generate a stunning high-res artwork
    if (apiKey) {
      try {
        const imagenUrl = `https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key=${apiKey}`;
        const imagenPayload = {
          instances: [{ prompt: prompt }],
          parameters: { sampleCount: 1, aspectRatio: "16:9" }
        };

        const res = await executeApiRequest(imagenUrl, 'POST', imagenPayload);
        if (res && res.predictions && res.predictions[0]?.bytesBase64Encoded) {
          imageUrl = `data:image/jpeg;base64,${res.predictions[0].bytesBase64Encoded}`;
        }
      } catch (e) {
        console.log('Imagen API fallback:', e);
      }
    }

    if (!imageUrl) {
      // Fallback high-def AI landscape generator for Android TV
      await new Promise(r => setTimeout(r, 1800));
      imageUrl = generateProceduralTvArt(prompt);
      explanation = `✨ Generated visualization based on: "${prompt}". Rendered in 16:9 widescreen for TV display.`;
    }

    removeTypingIndicator(typingId);

    appendMessage({
      id: 'msg_img_' + Date.now(),
      sender: 'gemini',
      text: explanation,
      imageUrl: imageUrl,
      imagePrompt: prompt,
      timestamp: new Date()
    });

    if (CONFIG.autoSpeak) {
      speakAloud('msg_img_' + Date.now(), `I have generated your image for ${prompt}.`);
    }
  }

  // Network Bridge: uses Native Android OkHttp when in WebView, or fetch()
  function executeApiRequest(url, method, payload) {
    return new Promise((resolve, reject) => {
      let isSettled = false;

      // 30-second safety timeout so Gemini response never hangs the app
      const timeoutTimer = setTimeout(() => {
        if (!isSettled) {
          isSettled = true;
          if (callbackId && nativeCallbackMap[callbackId]) {
            delete nativeCallbackMap[callbackId];
          }
          reject(new Error('Connection timed out. Please check your network connection.'));
        }
      }, 30000);

      const callbackId = 'cb_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

      nativeCallbackMap[callbackId] = {
        resolve: (data) => {
          if (!isSettled) {
            isSettled = true;
            clearTimeout(timeoutTimer);
            resolve(data);
          }
        },
        reject: (err) => {
          if (!isSettled) {
            isSettled = true;
            clearTimeout(timeoutTimer);
            reject(err);
          }
        }
      };

      if (window.Android && typeof window.Android.makeGeminiRequest === 'function') {
        try {
          const jsonBody = JSON.stringify(payload);
          const headers = JSON.stringify({ 'Content-Type': 'application/json' });
          window.Android.makeGeminiRequest(url, method, headers, jsonBody, callbackId);
        } catch (bridgeErr) {
          if (!isSettled) {
            isSettled = true;
            clearTimeout(timeoutTimer);
            delete nativeCallbackMap[callbackId];
            reject(bridgeErr);
          }
        }
      } else {
        fetch(url, {
          method: method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
          .then(res => res.json())
          .then(data => {
            if (!isSettled) {
              isSettled = true;
              clearTimeout(timeoutTimer);
              delete nativeCallbackMap[callbackId];
              resolve(data);
            }
          })
          .catch(err => {
            if (!isSettled) {
              isSettled = true;
              clearTimeout(timeoutTimer);
              delete nativeCallbackMap[callbackId];
              reject(err);
            }
          });
      }
    });
  }

  // Base64-safe Native callback receiver: immune to JavaScript escaping, quotes, or unicode syntax errors
  window.onNativeResponseBase64 = function (callbackId, statusCode, base64Data) {
    if (nativeCallbackMap[callbackId]) {
      try {
        const binString = atob(base64Data);
        const bytes = Uint8Array.from(binString, (m) => m.charCodeAt(0));
        const decodedText = new TextDecoder('utf-8').decode(bytes);
        const parsed = JSON.parse(decodedText);
        nativeCallbackMap[callbackId].resolve(parsed);
      } catch (e) {
        try {
          const fallbackText = decodeURIComponent(escape(atob(base64Data)));
          nativeCallbackMap[callbackId].resolve(JSON.parse(fallbackText));
        } catch (e2) {
          nativeCallbackMap[callbackId].resolve({ raw: base64Data, code: statusCode });
        }
      }
      delete nativeCallbackMap[callbackId];
    }
  };

  // Legacy Native callback receiver from MainActivity
  window.onNativeResponse = function (callbackId, statusCode, responseBody) {
    if (nativeCallbackMap[callbackId]) {
      try {
        const parsed = typeof responseBody === 'string' ? JSON.parse(responseBody) : responseBody;
        nativeCallbackMap[callbackId].resolve(parsed);
      } catch (e) {
        nativeCallbackMap[callbackId].resolve({ raw: responseBody, code: statusCode });
      }
      delete nativeCallbackMap[callbackId];
    }
  };

  window.onNativeError = function (callbackId, errorMessage) {
    if (nativeCallbackMap[callbackId]) {
      nativeCallbackMap[callbackId].reject(new Error(errorMessage));
      delete nativeCallbackMap[callbackId];
    }
  };

  /* ----------------------------------------------------
     Text-To-Speech (TTS) Voice Logic
  ---------------------------------------------------- */
  function speakAloud(messageId, text) {
    if (isSpeaking && currentlyPlayingAudioId === messageId) {
      stopSpeaking();
      return;
    }

    stopSpeaking();
    currentlyPlayingAudioId = messageId;
    isSpeaking = true;
    updateAudioBtnState(messageId, true);

    if (window.Android && typeof window.Android.speakText === 'function') {
      window.Android.speakText(text, 'en');
    } else if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.onend = () => {
        stopSpeaking();
      };
      utterance.onerror = () => {
        stopSpeaking();
      };
      window.speechSynthesis.speak(utterance);
    }
  }

  function stopSpeaking() {
    isSpeaking = false;
    if (currentlyPlayingAudioId) {
      updateAudioBtnState(currentlyPlayingAudioId, false);
      currentlyPlayingAudioId = null;
    }

    if (window.Android && typeof window.Android.stopSpeaking === 'function') {
      window.Android.stopSpeaking();
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  window.onSpeechStatus = function (speaking) {
    isSpeaking = speaking;
    if (!speaking && currentlyPlayingAudioId) {
      updateAudioBtnState(currentlyPlayingAudioId, false);
      currentlyPlayingAudioId = null;
    }
  };

  function updateAudioBtnState(messageId, playing) {
    const btn = document.getElementById('tts_btn_' + messageId);
    if (!btn) return;
    if (playing) {
      btn.innerHTML = '<span>⏹️</span><span>Stop</span>';
      btn.classList.add('playing');
    } else {
      btn.innerHTML = '<span>🔊</span><span>Listen</span>';
      btn.classList.remove('playing');
    }
  }

  function cleanTextForSpeech(text) {
    if (!text) return '';
    const cleaned = text
      .replace(/[*#`_~]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .trim();
    // Keep within safe TTS length (around 1200 characters) to avoid synthesis buffer overflows
    return cleaned.length > 1200 ? cleaned.substring(0, 1200) + '...' : cleaned;
  }

  /* ----------------------------------------------------
     UI Renderers: Messages, Markdown, Image viewer
  ---------------------------------------------------- */
  function appendMessage(msg) {
    chatMessages.push(msg);

    const wrapper = document.createElement('div');
    wrapper.className = `message-bubble-wrapper ${msg.sender}`;
    wrapper.id = 'wrap_' + msg.id;

    const card = document.createElement('div');
    card.className = 'message-card';

    // Header
    const header = document.createElement('div');
    header.className = 'msg-header';

    const author = document.createElement('div');
    author.className = 'msg-author';
    if (msg.sender === 'gemini') {
      author.innerHTML = '<span class="msg-author-icon">✨</span> Gemini AI';
    } else {
      author.innerHTML = 'You';
    }
    header.appendChild(author);

    if (msg.sender === 'gemini') {
      const actions = document.createElement('div');
      actions.className = 'msg-actions';

      const ttsBtn = document.createElement('button');
      ttsBtn.className = 'action-icon-btn';
      ttsBtn.id = 'tts_btn_' + msg.id;
      ttsBtn.tabIndex = 0;
      ttsBtn.innerHTML = '<span>🔊</span><span>Listen</span>';
      ttsBtn.addEventListener('click', () => {
        speakAloud(msg.id, cleanTextForSpeech(msg.text));
      });

      actions.appendChild(ttsBtn);
      header.appendChild(actions);
    }

    card.appendChild(header);

    // Body text (with basic markdown parsing)
    const content = document.createElement('div');
    content.className = 'msg-content';
    content.innerHTML = formatMarkdown(msg.text);
    card.appendChild(content);

    // Image card if present
    if (msg.imageUrl) {
      const imgCard = document.createElement('div');
      imgCard.className = 'generated-image-card';
      imgCard.tabIndex = 0;
      imgCard.innerHTML = `
        <img src="${msg.imageUrl}" alt="${escapeHtml(msg.imagePrompt || 'Generated Image')}" />
        <div class="img-caption">
          <span>🎨 ${escapeHtml(msg.imagePrompt || 'Artwork')}</span>
          <span style="color:#38BDF8;">[OK to Enlarge]</span>
        </div>
      `;

      imgCard.addEventListener('click', () => {
        openImageViewer(msg.imageUrl, msg.imagePrompt);
      });
      imgCard.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') openImageViewer(msg.imageUrl, msg.imagePrompt);
      });

      card.appendChild(imgCard);
    }

    wrapper.appendChild(card);
    chatHistory.appendChild(wrapper);
  }

  function appendTypingIndicator(id, text) {
    const wrapper = document.createElement('div');
    wrapper.className = 'message-bubble-wrapper gemini';
    wrapper.id = id;

    const card = document.createElement('div');
    card.className = 'message-card';

    const indicator = document.createElement('div');
    indicator.className = 'typing-indicator';
    indicator.innerHTML = `
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <span style="margin-left: 10px; font-size: 15px; color: #94A3B8;">${escapeHtml(text)}</span>
    `;

    card.appendChild(indicator);
    wrapper.appendChild(card);
    chatHistory.appendChild(wrapper);
  }

  function removeTypingIndicator(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  }

  function scrollToBottom() {
    setTimeout(() => {
      tvMainScreen.scrollTo({
        top: tvMainScreen.scrollHeight,
        behavior: 'smooth'
      });
    }, 100);
  }

  function openImageViewer(url, prompt) {
    modalImgPreview.src = url;
    modalImgPrompt.textContent = prompt || '';
    imageOverlay.classList.add('active');
    imageOverlay.setAttribute('aria-hidden', 'false');
    setTimeout(() => closeImageBtn.focus(), 100);
  }

  closeImageBtn.addEventListener('click', () => {
    imageOverlay.classList.remove('active');
    imageOverlay.setAttribute('aria-hidden', 'true');
    askGeminiInput.focus();
  });

  /* ----------------------------------------------------
     Settings Modal
  ---------------------------------------------------- */
  function openSettingsModal() {
    settingsOverlay.classList.add('active');
    settingsOverlay.setAttribute('aria-hidden', 'false');
    setTimeout(() => settingsApiKey.focus(), 100);
  }

  function closeSettingsModal() {
    settingsOverlay.classList.remove('active');
    settingsOverlay.setAttribute('aria-hidden', 'true');
    askGeminiInput.focus();
  }

  saveSettingsBtn.addEventListener('click', () => {
    CONFIG.apiKey = settingsApiKey.value.trim();
    CONFIG.model = settingsModelSelect.value;
    CONFIG.autoSpeak = autoSpeakToggle.checked;

    localStorage.setItem('gemini_api_key', CONFIG.apiKey);
    localStorage.setItem('gemini_model', CONFIG.model);
    localStorage.setItem('gemini_auto_speak', String(CONFIG.autoSpeak));

    updateStatusBadge();
    closeSettingsModal();

    if (window.Android && typeof window.Android.showToast === 'function') {
      window.Android.showToast('Settings saved successfully');
    }
  });

  closeSettingsBtn.addEventListener('click', closeSettingsModal);

  /* ----------------------------------------------------
     Android TV Remote Navigation & Keyboard Handling
  ---------------------------------------------------- */
  document.addEventListener('keydown', (e) => {
    // Audio feedback on arrow keys
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
      playTvBeep(360, 0.03);
    }

    // Handle Escape or Back key
    if (e.key === 'Escape' || e.key === 'Backspace' && e.target === document.body) {
      window.handleTvBackPress();
    }
  });

  window.handleTvBackPress = function () {
    if (voiceOverlay.classList.contains('active')) {
      stopVoiceDictation(false);
      return 'true';
    }
    if (imageOverlay.classList.contains('active')) {
      imageOverlay.classList.remove('active');
      imageOverlay.setAttribute('aria-hidden', 'true');
      return 'true';
    }
    if (settingsOverlay.classList.contains('active')) {
      closeSettingsModal();
      return 'true';
    }
    if (isSpeaking) {
      stopSpeaking();
      return 'true';
    }
    return 'false';
  };

  /* ----------------------------------------------------
     Helper Functions (Markdown, Escaping, Generators)
  ---------------------------------------------------- */
  function formatMarkdown(text) {
    if (!text) return '';
    try {
      if (window.Android && typeof window.Android.processNativeText === 'function') {
        const nativeFormatted = window.Android.processNativeText(text);
        if (nativeFormatted) {
          text = nativeFormatted;
        }
      }
    } catch (e) {
      console.warn('Native processor call fallback', e);
    }

    try {
      const lines = text.split('\n');
      const output = [];
      let inList = false;

      for (let i = 0; i < lines.length; i++) {
        let line = escapeHtml(lines[i]);

        // Code block triple backticks toggle
        if (line.startsWith('```')) {
          if (inList) { output.push('</ul>'); inList = false; }
          output.push('<div class="code-block-notice">💻 Code:</div>');
          continue;
        }

        // Bold formatting
        line = line.replace(/&lt;b&gt;(.*?)&lt;\/b&gt;/g, '<strong style="color:var(--color-primary)">$1</strong>');
        line = line.replace(/\*\*(.*?)\*\*/g, '<strong style="color:var(--color-primary)">$1</strong>');
        // Inline code
        line = line.replace(/`([^`]+)`/g, '<code>$1</code>');
        // Italic (single asterisk, not bullet)
        line = line.replace(/(?<!\*)\*([^\*]+)\*(?!\*)/g, '<em>$1</em>');

        // Bullet point lines
        const bulletMatch = line.match(/^(\s*)(?:[\*\-]|\d+\.)\s+(.+)$/);
        if (bulletMatch) {
          if (!inList) {
            output.push('<ul class="tv-bullet-list">');
            inList = true;
          }
          output.push(`<li>${bulletMatch[2]}</li>`);
        } else {
          if (inList) {
            output.push('</ul>');
            inList = false;
          }
          if (line.trim().length === 0) {
            output.push('<br/>');
          } else {
            output.push(`<p>${line}</p>`);
          }
        }
      }

      if (inList) {
        output.push('</ul>');
      }

      return output.join('');
    } catch (err) {
      console.error('Markdown format error', err);
      return `<p>${escapeHtml(text)}</p>`;
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Smart high-grade procedural SVG artist for big-screen TVs when Imagen is offline
  function generateProceduralTvArt(prompt) {
    const seed = Math.abs(hashString(prompt));
    const h1 = seed % 360;
    const h2 = (h1 + 60) % 360;
    const h3 = (h1 + 180) % 360;

    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720">
        <defs>
          <linearGradient id="sky" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="hsl(${h1}, 75%, 12%)" />
            <stop offset="50%" stop-color="hsl(${h2}, 85%, 22%)" />
            <stop offset="100%" stop-color="hsl(${h3}, 90%, 8%)" />
          </linearGradient>
          <radialGradient id="sun" cx="50%" cy="40%" r="50%">
            <stop offset="0%" stop-color="#FFFFFF" />
            <stop offset="30%" stop-color="hsl(${h2}, 100%, 75%)" />
            <stop offset="100%" stop-color="hsl(${h1}, 90%, 50%)" stop-opacity="0" />
          </radialGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="15" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        <rect width="1280" height="720" fill="url(#sky)" />
        <circle cx="640" cy="280" r="160" fill="url(#sun)" filter="url(#glow)" />
        
        <!-- Mountainous silhouettes -->
        <path d="M0,720 L0,480 Q320,320 640,490 T1280,440 L1280,720 Z" fill="hsl(${h1}, 50%, 15%)" opacity="0.8" />
        <path d="M0,720 L0,550 Q400,380 800,560 T1280,510 L1280,720 Z" fill="hsl(${h3}, 60%, 10%)" />
        <path d="M0,720 L0,620 Q500,480 1000,640 T1280,580 L1280,720 Z" fill="hsl(${h2}, 70%, 6%)" />

        <!-- Star clusters -->
        ${Array.from({ length: 45 }).map((_, i) => {
          const cx = ((i * 137 + seed) % 1240) + 20;
          const cy = ((i * 89 + seed) % 360) + 20;
          const r = (i % 3) + 1.2;
          return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#FFFFFF" opacity="${0.4 + (i % 5) * 0.15}" />`;
        }).join('')}

        <!-- Water / Horizon Glow -->
        <rect y="640" width="1280" height="80" fill="hsl(${h2}, 80%, 14%)" opacity="0.6" />
        <line x1="0" y1="640" x2="1280" y2="640" stroke="hsl(${h1}, 100%, 75%)" stroke-width="2" opacity="0.7" />
      </svg>
    `;

    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  function hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return hash;
  }

  function generateSmartTvResponse(prompt) {
    const lower = prompt.toLowerCase();
    if (lower.includes('movie') || lower.includes('cinema') || lower.includes('film')) {
      return `Here are 3 premier sci-fi films recommended for your big screen:\n\n1. **Interstellar (2014)** – A visually stunning space odyssey about endurance, quantum physics, and human connection.\n2. **Blade Runner 2049 (2017)** – Breathtaking cyberpunk cinematography, deep philosophical questions, and incredible sound design.\n3. **Arrival (2016)** – A brilliant masterpiece exploring extraterrestrial linguistics, perception of time, and profound global unity.`;
    }
    if (lower.includes('story') || lower.includes('গল্প') || lower.includes('bedtime')) {
      return `Deep within the celestial canopy, where constellations weave radiant ribbons across the night, there exists an enchanted observatory. Every star pulses with harmonic resonance, singing silent melodies of peace and wonder. As starlight settles gently onto the quiet earth below, night falls in complete calm and tranquility. Rest well.`;
    }
    if (lower.includes('black hole') || lower.includes('space')) {
      return `**Black Holes Explained Simply:**\n\nA black hole is a region in spacetime where gravity is so overwhelmingly strong that nothing—not even light—can escape its grasp. It forms when an enormous dying star collapses in upon itself into an infinitely dense point known as a **singularity**.\n\nSurrounding it is the **event horizon**, the theoretical point of no return. Beyond this boundary, physics as we understand it warps, time slows down dramatically, and the universe's greatest mysteries lie concealed.`;
    }
    return `Hello! I am Google Gemini on your Android TV. I can converse with you about any topic, answer complex questions, narrate stories, generate creative ideas, and produce visuals. What would you like to explore next?`;
  }

  // Run initializations
  initConfig();
  updateSendButtonVisibility();

  // Focus the input box on startup for immediate Android TV remote usability
  setTimeout(() => {
    askGeminiInput.focus();
  }, 400);

})();
